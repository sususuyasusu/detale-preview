<?php
// detale.jp お問い合わせフォームの受け口（2026-11-21 本番公開で新設）。
// フォームの内容を info@detale.jp へメールで届ける（info@ は Gmail へ取り込み済みの実在の窓口）。
// 返事の宛先（Reply-To）はお客様のメールアドレス。ロボットよけ: 見えない欄 website に何か入っていたら捨てる。
header('Content-Type: application/json; charset=UTF-8');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo '{"ok":false}'; exit; }
mb_language('Japanese'); mb_internal_encoding('UTF-8');
function v($k, $max = 2000) { $s = isset($_POST[$k]) ? (string)$_POST[$k] : ''; $s = str_replace(array("\r\n", "\r"), "\n", $s); return mb_substr(trim($s), 0, $max); }
if (v('website') !== '') { echo '{"ok":true}'; exit; }
$email = v('email', 200);
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { http_response_code(400); echo '{"ok":false,"err":"email"}'; exit; }
$sceneNames = array('brand' => 'ブランドを作りたい', 'sales' => '売上を上げたい', 'value' => 'ブランドを高めたい');
$scene = v('scene', 20); $scene = isset($sceneNames[$scene]) ? $sceneNames[$scene] : '（選択なし）';
$services = v('services', 1000); if ($services === '') $services = '（選択なし）';
$body = "detale.jp のお問い合わせフォームから届きました。\n\n"
  . "会社名・店名: " . v('company', 200) . "\n"
  . "お名前: " . v('name', 200) . "\n"
  . "メール: " . $email . "\n"
  . "電話: " . v('tel', 50) . "\n"
  . "シーンで選ぶ: " . $scene . "\n"
  . "サービスで選ぶ: " . $services . "\n\n"
  . "ご相談内容:\n" . v('message', 5000) . "\n\n"
  . "----\n受付日時: " . date('Y-m-d H:i') . "\n送信元: " . (isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '') . "\n";
$to = 'info@detale.jp';
$subject = '【detale.jp お問い合わせ】' . (v('company', 60) !== '' ? v('company', 60) : v('name', 60));
$headers = "From: info@detale.jp\r\nReply-To: " . $email;
$ok = mb_send_mail($to, $subject, $body, $headers, '-f info@detale.jp');
if (!$ok) { http_response_code(500); echo '{"ok":false,"err":"mail"}'; exit; }
echo '{"ok":true}';
